// =============================================
// GLOBAL VARIABLES AND API SETUP
// =============================================
// *** IMPORTANT: Replace these placeholders with your actual API details if using a real API ***
const RECIPE_API_ENDPOINT = "YOUR_RECIPE_API_URL"; 
const RESTAURANT_API_ENDPOINT = "YOUR_RESTAURANT_API_URL"; 


// =============================================
// MAIN SEARCH HANDLER (Event Listener and Validation)
// =============================================
document.getElementById('food-search-form').addEventListener('submit', function(event) {
    event.preventDefault(); 
    
    const searchTerm = document.getElementById('search-input').value.trim();
    
    // 1. Input Validation (Required)
    if (searchTerm === "") {
        document.getElementById('search-input').classList.add('is-invalid');
        document.getElementById('validation-feedback').style.display = 'block';
        return;
    } else {
        document.getElementById('search-input').classList.remove('is-invalid');
        document.getElementById('validation-feedback').style.display = 'none';
    }

    // Show loading messages
    document.getElementById('recipe-list').innerHTML = '<p class="text-center text-muted">Searching for recipes...</p>';
    document.getElementById('restaurant-list').innerHTML = '<p class="text-center text-muted">Searching for nearby restaurants...</p>';

    // Initiate API Calls
    fetchAndDisplayRecipes(searchTerm);
    fetchAndDisplayRestaurants(searchTerm);
});

// =============================================
// RECIPE FETCHING AND DISPLAY (Dynamic Content)
// =============================================
function fetchAndDisplayRecipes(query) {
    // *** SIMULATION: Simulate API response data for demonstration ***
    const simulatedRecipeData = [
        { 
            label: 'Shredded Chicken Porridge', 
            // Correct image placeholder URL for successful display
            image: 'https://via.placeholder.com/400x200?text=Chicken+Porridge', 
            source: 'Chinese Cuisine', 
            url: 'https://en.wikipedia.org/wiki/Congee', 
            ingredients: [{text: '1 cup of rice'}, {text: 'Shredded chicken'}, {text: 'Water'}, {text: 'Ginger'}] 
        },
        { 
            label: 'Cendol', 
            image: 'https://via.placeholder.com/400x200?text=Cendol+Dessert', 
            source: 'Dessert', 
            url: 'https://en.wikipedia.org/wiki/Cendol', 
            ingredients: [{text: 'Shaved ice'}, {text: 'Red beans'}, {text: 'Coconut Milk'},{text:'Gula Melaka (Palm Sugar)'}] 
        },
        { 
            label: 'Sauna Mee Fish', 
            image: 'https://via.placeholder.com/400x200?text=Sauna+Mee+Fish+Hot+Pot', 
            source: 'Hot Pot', 
            url: 'https://www.google.com/search?q=sauna+mee', 
            ingredients: [{text: 'Fish Slices'}, {text: 'Mixed vegetables'}, {text: 'Hot Soup'},{text:'Mushrooms'}] 
        },
    ];
    // *** END SIMULATION ***
    
    const recipeList = document.getElementById('recipe-list');
    recipeList.innerHTML = ''; 

    if (simulatedRecipeData.length > 0) {
        simulatedRecipeData.forEach(recipe => {
            // Create and append the Bootstrap Card (Recipe Result)
            recipeList.insertAdjacentHTML('beforeend', createRecipeCard(recipe));
        });
    } else {
        recipeList.innerHTML = '<p class="text-center text-danger">No recipes found. Try a different search.</p>';
    }
}

/**
 * Builds the HTML Card structure for a single recipe result.
 */
function createRecipeCard(recipe) {
    const recipeJson = JSON.stringify(recipe); 

    return `
        <div class="col">
            <div class="card h-100 shadow-sm">
                
                <img src="${recipe.image}" class="card-img-top" alt="${recipe.label}">
                
                <div class="card-body">
                    <h5 class="card-title text-primary">${recipe.label}</h5> 
                    <p class="card-text"><small class="text-muted">Source: ${recipe.source}</small></p>

                    <button type="button" class="btn btn-sm btn-outline-info mt-2" 
                        data-bs-toggle="modal" 
                        data-bs-target="#recipeModal" 
                        data-recipe='${recipeJson}'>
                        <i class="bi bi-book"></i> View Details
                    </button>
                </div>
            </div>
        </div>
    `;
}

// =============================================
// MODAL DETAILS HANDLER (Displaying Food Details)
// =============================================
document.getElementById('recipeModal').addEventListener('show.bs.modal', function (event) {
    const button = event.relatedTarget; 
    const recipeData = JSON.parse(button.getAttribute('data-recipe'));
    
    const modalTitle = document.getElementById('recipeModalLabel');
    const modalContentArea = document.getElementById('modal-content-area');

    modalTitle.textContent = recipeData.label;
    
    // Populate modal body with detailed food information (image, ingredients, link)
    modalContentArea.innerHTML = `
        <div class="text-center mb-3">
            <img src="${recipeData.image}" class="img-fluid rounded shadow-sm" alt="${recipeData.label}">
        </div>

        <h4>Ingredients List</h4>
        <ul class="list-group list-group-flush mb-4">
            ${recipeData.ingredients.map(ing => 
                `<li class="list-group-item"><i class="bi bi-check-circle-fill text-success me-2"></i>${ing.text}</li>`
            ).join('')}
        </ul>
        
        <div class="d-grid">
            <a href="${recipeData.url}" target="_blank" class="btn btn-primary btn-lg">
                <i class="bi bi-box-arrow-up-right"></i> View Full Recipe Source
            </a>
        </div>
    `;
});

// =============================================
// RESTAURANT FETCHING AND DISPLAY (Simulation)
// =============================================
function fetchAndDisplayRestaurants(query) {
    // *** SIMULATION ***
    setTimeout(() => {
        const restaurantList = document.getElementById('restaurant-list');
        restaurantList.innerHTML = '';

        const simulatedRestaurantData = [
            { name: 'Yee Kee Porridge Restaurant ', serves: query, distance: '1.5 miles', rating: '4.8', category: 'local dishes' },
            { name: 'MamaKim Wellness Kitchen', serves: 'hot pot, ' + query, distance: '0.5 miles', rating: '4.7', category: 'hot pot' },
        ];
        
        if (simulatedRestaurantData.length > 0) {
            simulatedRestaurantData.forEach(restaurant => {
                restaurantList.insertAdjacentHTML('beforeend', createRestaurantListItem(restaurant));
            });
        } else {
             restaurantList.innerHTML = '<p class="text-center text-danger">No restaurants found nearby serving that item.</p>';
        }

    }, 1000); 
}

function createRestaurantListItem(restaurant) {
    const starColor = restaurant.rating >= 4.5 ? 'bg-success' : 'bg-warning text-dark';
    
    return `
        <a href="#" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
            <div>
                <h5 class="mb-1">
                    <i class="bi bi-geo-alt-fill me-2"></i> ${restaurant.name} 
                    <small class="text-muted"> (Serves: ${restaurant.serves})</small>
                </h5>
                <small class="text-muted">${restaurant.distance} away. Specializes in ${restaurant.category}.</small>
            </div>
            <span class="badge ${starColor}">
                <i class="bi bi-star-fill"></i> ${restaurant.rating}
            </span>
        </a>
    `;
}

// =============================================
// CONTACT FORM HANDLER (Optional: For simple validation)
// =============================================
document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault(); 
    
    // Simple frontend validation check
    const emailInput = document.getElementById('contactEmail');
    if (!emailInput.value.includes('@')) {
        alert('Please enter a valid email address.');
        emailInput.focus();
        return;
    }
    
    alert('Thank you for your message! We will get back to you soon.');
    document.getElementById('contact-form').reset();
});
