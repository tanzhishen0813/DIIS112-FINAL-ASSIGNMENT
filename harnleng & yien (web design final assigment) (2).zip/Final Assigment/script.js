const foodData = [
    {
        name: "Chicken Alfredo",
        img: "chicken-alfredo-index-64ee1026c82a9.jpg",
        desc: "Creamy pasta with grilled chicken and parmesan cheese.",
        calories: "650 kcal",
        category: "Western",
        difficulty: "Medium",
        restaurants: ["Olive Garden", "Tony's Pasta", "Mama Mia Ristorante"]
    },
    {
        name: "Pizza",
        img: "MY_PXBP_en_menu_12818.jpg",
        desc: "A cheesy, savory pizza perfect for any meal.",
        calories: "780 kcal",
        category: "Italian",
        difficulty: "Easy",
        restaurants: ["Pizza Hut", "Domino's", "Little Italy"] 
    },
    {
    name: "Chicken Burger", 
    img: "Chicken-Hash-Brown-Burger.jpg",
    desc: "Juicy chicken patty topped with cheese and fresh vegetables", 
    calories: "850 kcal",
    category: "American",
    difficulty: "Easy",
    restaurants: ["Burger King", "McDonald's", "Grill House"]
},
    {
        name: "Sushi Platter",
        img: "Screenshot-2025-02-21-163817.jpg",
        desc: "Fresh salmon, tuna and rice rolls.",
        calories: "450 kcal",
        category: "Japanese",
        difficulty: "Hard",
        restaurants: ["Sushi Zanmai", "Sushi King", "Genki Sushi"] 
    }
];

const searchInput = document.getElementById("searchInput");
const searchBtn = document.getElementById("searchBtn");
const results = document.getElementById("results");
const errorMsg = document.getElementById("errorMsg");

searchBtn.onclick = () => {
    const q = searchInput.value.trim().toLowerCase();
    results.innerHTML = "";
    errorMsg.textContent = "";

    if (!q) {
        errorMsg.textContent = "Please enter a search term.";
        return;
    }

    const filtered = foodData.filter(item =>
        item.name.toLowerCase().includes(q)
    );

    if (filtered.length === 0) {
        results.innerHTML = `<p class="text-center text-secondary">No results found.</p>`;
        return;
    }

    filtered.forEach((food, index) => {
        const delay = index * 0.15;

        results.innerHTML += `
            <div class="col-md-4">
                <div class="card p-3" style="animation-delay:${delay}s" onclick="openModal('${food.name}')">
                    <img src="${food.img}" class="card-img-top">
                    <h5 class="mt-3 fw-bold">${food.name}</h5>
                    <p class="mb-1">Calories: ${food.calories}</p>
                    <p class="mb-1">Category: ${food.category}</p>
                    <p class="mb-1">Difficulty: ${food.difficulty}</p>
                </div>
            </div>`;
    });
};

function openModal(name) {
    const food = foodData.find(f => f.name === name);

    document.getElementById("modalTitle").textContent = food.name;
    document.getElementById("modalImage").src = food.img;
    document.getElementById("modalDesc").textContent = food.desc;
    document.getElementById("modalCalories").textContent = food.calories;
    document.getElementById("modalCategory").textContent = food.category;
    document.getElementById("modalDifficulty").textContent = food.difficulty;
    document.getElementById("modalRestaurants").textContent = food.restaurants.join(", ");

    new bootstrap.Modal(document.getElementById("recipeModal")).show();
}

window.addEventListener("scroll", () => {
    const nav = document.getElementById("navbar");
    if (window.scrollY > 50) {
        nav.classList.add("nav-scrolled");
    } else {
        nav.classList.remove("nav-scrolled");
    }
});